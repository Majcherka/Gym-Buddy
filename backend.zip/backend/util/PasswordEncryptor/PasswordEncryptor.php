<?php

namespace util\PasswordEncryptor;
interface PasswordEncryptor
{
    public function encrypt(string $plain): string;
}