<?php

return [
    'password_encryptor' => 'default'  // options: default, md5, plaintext
];